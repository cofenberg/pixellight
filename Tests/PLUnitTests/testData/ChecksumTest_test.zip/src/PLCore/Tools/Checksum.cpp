//[-------------------------------------------------------]
//[ Includes                                              ]
//[-------------------------------------------------------]
#include <UnitTest++/UnitTest++.h>
#include <PLCore/Tools/ChecksumCRC32.h>
#include <PLCore/Tools/ChecksumMD5.h>
#include <PLCore/Tools/ChecksumSHA1.h>
#include <PLCore/File/File.h>
#include <PLCore/String/String.h>

#include "UnitTest++AddIns\PLCheckMacros.h"
#include "UnitTest++AddIns\PLChecks.h"

/*
* Naming Convention for SUITE:
* CLASSNAME
*/
SUITE(Checksum) {
	/*
	* Naming Convention for METHOD:
	* METHODNAME_SCENARIO
	*/

	// Our Array Test Fixture :)
	struct ConstructTest
	{
		ConstructTest()
			/* some setup */
		{
		}
		~ConstructTest() {
			/* some teardown */
		}

		// Container for testing
		PLCore::ChecksumCRC32 sumCRC;
		PLCore::ChecksumMD5 sumMD5;
		PLCore::ChecksumSHA1 sumSHA1;
		PLCore::String sChecksum;
	};

	PLCore::String CheckFile(PLCore::Checksum &cChecksum, const PLCore::String &sFilename)
	{
		// Check the given parameter
		if (!sFilename.GetLength()) return ""; 

		// Open the file
		PLCore::File cFile(sFilename);

		// Fool the checksum function ;-)
		/* Assertion...
		String sChecksum = Checksum::Get(sClass, pFile);
		if (sChecksum.GetLength()) {
		pFile->Release();

		// Error!
		return "";
		}
		*/

		// Open the file
		if (!cFile.Open(PLCore::File::FileRead)) {
			// Error!
			return "";
		}

		// Get the checksum
		PLCore::String sChecksum = cChecksum.Get(cFile);

		// Check the current file offset
		if (cFile.Tell()) sChecksum = ""; 

		// Close the file
		cFile.Close();

		// Done
		return sChecksum;
	};

	// ChecksumMD5
	// ChecksumMD5: Get(const PLCore::uint8 nBuffer[], PLCore::uint32 nNumOfBytes)
	TEST_FIXTURE(ConstructTest, ChecksumMD5__Get_const_uint8_nBuffer____uint32_nNumOfBytes_) {
		// Alphabet
		sChecksum = sumMD5.Get(reinterpret_cast<const PLCore::uint8*>("abcdefghijklmnopqrstuvwxyz"), static_cast<PLCore::uint32>(strlen("abcdefghijklmnopqrstuvwxyz")));
		CHECK_EQUAL("c3fcd3d76192e4007dfb496cca67e13b", sChecksum.GetASCII());

		// Corrupted alphabet (one of the letters in the alphabet (in this case 'm') is changed to uppercase)
		sChecksum = sumMD5.Get(reinterpret_cast<const PLCore::uint8*>("abcdefghijklMnopqrstuvwxyz"), static_cast<PLCore::uint32>(strlen("abcdefghijklMnopqrstuvwxyz")));
		CHECK(sChecksum  != "c3fcd3d76192e4007dfb496cca67e13b");

		// Alphabet and numbers
		sChecksum = sumMD5.Get(reinterpret_cast<const PLCore::uint8*>("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"), static_cast<PLCore::uint32>(strlen("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")));
		// [TODO] fails!
		CHECK_EQUAL("d174ab98d277d9f5a5611c2c9f419d9f", sChecksum.GetASCII());

		// Corrupted alphabet and numbers ('9' removed)
		sChecksum = sumMD5.Get(reinterpret_cast<const PLCore::uint8*>("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz012345678"), static_cast<PLCore::uint32>(strlen("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz012345678")));
		CHECK(sChecksum  != "d174ab98d277d9f5a5611c2c9f419d9f");
	}

	// ChecksumMD5: Get(const String &sString)
	TEST_FIXTURE(ConstructTest, ChecksumMD5__Get_const_String__sString_) {
		// Alphabet
		sChecksum = sumMD5.Get("abcdefghijklmnopqrstuvwxyz");
		CHECK_EQUAL("c3fcd3d76192e4007dfb496cca67e13b", sChecksum.GetASCII());

		// Corrupted alphabet (one of the letters in the alphabet (in this case 'm') is changed to uppercase)
		sChecksum = sumMD5.Get("abcdefghijklMnopqrstuvwxyz");
		CHECK(sChecksum  != "c3fcd3d76192e4007dfb496cca67e13b");

		// Alphabet and numbers
		sChecksum = sumMD5.Get("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
		// [TODO] fails!
		CHECK_EQUAL("d174ab98d277d9f5a5611c2c9f419d9f", sChecksum.GetASCII());

		// Corrupted alphabet and numbers ('9' removed)
		sChecksum = sumMD5.Get("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz012345678");
		CHECK(sChecksum  != "d174ab98d277d9f5a5611c2c9f419d9f");

		// Unicode
		// [TODO] warning: universal character name encountered in source
		sChecksum = sumMD5.Get(L"\u65e5\u672c\u8a9e");
		// [TODO] fails!
		CHECK_EQUAL("965f626b62b499198df91ae051f13bd2", sChecksum.GetASCII());

		// Alphabet and numbers - this time as Unicode
		sChecksum = sumMD5.Get(L"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
		CHECK(sChecksum  != "d174ab98d277d9f5a5611c2c9f419d9f");
	}

	// ChecksumMD5: Get(File &cFile)
	TEST_FIXTURE(ConstructTest, ChecksumMD5__Get_File__cFile_) {
		// Check 'demotest.xml'
		sChecksum = CheckFile(sumMD5, "demotest.xml");
		CHECK_EQUAL("caf5fe7d6c372d213627d51147c889c8", sChecksum.GetASCII());

		// Check 'tokenizer.txt'
		sChecksum = CheckFile(sumMD5, "tokenizer.txt");
		CHECK_EQUAL("e8d4c6ef5f6ab8d5750f012a8633a315", sChecksum.GetASCII());

		// Check 'test.zip'
		sChecksum = CheckFile(sumMD5, "test.zip");
		CHECK_EQUAL("d9bdfd82c142eccbb6237b32f90422a0", sChecksum.GetASCII());
	}

	// ChecksumMD5: GetFile(const String &sFilename)
	TEST_FIXTURE(ConstructTest, ChecksumMD5__Get_const_String__sFilename_) {
		// Check 'demotest.xml'
		sChecksum = sumMD5.GetFile("demotest.xml");
		CHECK_EQUAL("caf5fe7d6c372d213627d51147c889c8", sChecksum.GetASCII());

		// Check 'tokenizer.txt'
		sChecksum = sumMD5.GetFile("tokenizer.txt");
		CHECK_EQUAL("e8d4c6ef5f6ab8d5750f012a8633a315", sChecksum.GetASCII());

		// Check 'test.zip'
		sChecksum = sumMD5.GetFile("test.zip");
		CHECK_EQUAL("d9bdfd82c142eccbb6237b32f90422a0", sChecksum.GetASCII());
	}


	// ChecksumCRC32
	// ChecksumCRC32: Get(const PLCore::uint8 nBuffer[], PLCore::uint32 nNumOfBytes)
	TEST_FIXTURE(ConstructTest, ChecksumCRC32__Get_const_uint8_nBuffer____uint32_nNumOfBytes_) {
		// Alphabet
		sChecksum = sumCRC.Get(reinterpret_cast<const PLCore::uint8*>("abcdefghijklmnopqrstuvwxyz"), static_cast<PLCore::uint32>(strlen("abcdefghijklmnopqrstuvwxyz")));
		CHECK_EQUAL("4c2750bd", sChecksum.GetASCII());

		// Corrupted alphabet (one of the letters in the alphabet (in this case 'm') is changed to uppercase)
		sChecksum = sumCRC.Get(reinterpret_cast<const PLCore::uint8*>("abcdefghijklMnopqrstuvwxyz"), static_cast<PLCore::uint32>(strlen("abcdefghijklMnopqrstuvwxyz")));
		CHECK(sChecksum  != "4c2750bd");

		// Alphabet and numbers
		sChecksum = sumCRC.Get(reinterpret_cast<const PLCore::uint8*>("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"), static_cast<PLCore::uint32>(strlen("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")));
		CHECK_EQUAL("1fc2e6d2", sChecksum.GetASCII());

		// Corrupted alphabet and numbers ('9' removed)
		sChecksum = sumCRC.Get(reinterpret_cast<const PLCore::uint8*>("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz012345678"), static_cast<PLCore::uint32>(strlen("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz012345678")));
		CHECK(sChecksum  != "170fccc");
	}

	// ChecksumCRC32: Get(const String &sString)
	TEST_FIXTURE(ConstructTest, ChecksumCRC32__Get_const_String__sString_) {
		// Alphabet
		sChecksum = sumCRC.Get("abcdefghijklmnopqrstuvwxyz");
		CHECK_EQUAL("4c2750bd", sChecksum.GetASCII());

		// Corrupted alphabet (one of the letters in the alphabet (in this case 'm') is changed to uppercase)
		sChecksum = sumCRC.Get("abcdefghijklMnopqrstuvwxyz");
		CHECK(sChecksum  != "4c2750bd");

		// Alphabet and numbers
		sChecksum = sumCRC.Get("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
		CHECK_EQUAL("1fc2e6d2", sChecksum.GetASCII());

		// Corrupted alphabet and numbers ('9' removed)
		sChecksum = sumCRC.Get("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz012345678");
		CHECK(sChecksum  != "1fc2e6d2");

		// Unicode
		sChecksum = sumCRC.Get(L"\u65e5\u672c\u8a9e");
		CHECK_EQUAL("e34ad326", sChecksum.GetASCII());

		// Alphabet and numbers - this time as Unicode
		sChecksum = sumCRC.Get(L"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
		CHECK(sChecksum  != "e34ad326");
	}

	// ChecksumCRC32: Get(File &cFile)
	TEST_FIXTURE(ConstructTest, ChecksumCRC32__Get_File__cFile_) {
		// Check 'demotest.xml'
		sChecksum = CheckFile(sumCRC, "demotest.xml");
		CHECK_EQUAL("879c2363", sChecksum.GetASCII());

		// Check 'tokenizer.txt'
		sChecksum = CheckFile(sumCRC, "tokenizer.txt");
		CHECK_EQUAL("fbab7f1f", sChecksum.GetASCII());

		// Check 'test.zip'
		sChecksum = CheckFile(sumCRC, "test.zip");
		CHECK_EQUAL("84ee7986", sChecksum.GetASCII());
	}

	// ChecksumCRC32: GetFile(const String &sFilename)
	TEST_FIXTURE(ConstructTest, ChecksumCRC32__Get_const_String__sFilename_) {
		// Check 'demotest.xml'
		sChecksum = sumCRC.GetFile("demotest.xml");
		CHECK_EQUAL("879c2363", sChecksum.GetASCII());

		// Check 'tokenizer.txt'
		sChecksum = sumCRC.GetFile("tokenizer.txt");
		CHECK_EQUAL("fbab7f1f", sChecksum.GetASCII());

		// Check 'test.zip'
		sChecksum = sumCRC.GetFile("test.zip");
		CHECK_EQUAL("84ee7986", sChecksum.GetASCII());
	}


	// ChecksumSHA1
	// ChecksumSHA1: Get(const PLCore::uint8 nBuffer[], PLCore::uint32 nNumOfBytes)
	TEST_FIXTURE(ConstructTest, ChecksumSHA1__Get_const_uint8_nBuffer____uint32_nNumOfBytes_) {
		// Alphabet
		sChecksum = sumSHA1.Get(reinterpret_cast<const PLCore::uint8*>("abcdefghijklmnopqrstuvwxyz"), static_cast<PLCore::uint32>(strlen("abcdefghijklmnopqrstuvwxyz")));
		CHECK_EQUAL("32d10c7b8cf96570ca04ce37f2a19d84240d3a89", sChecksum.GetASCII());

		// Corrupted alphabet (one of the letters in the alphabet (in this case 'm') is changed to uppercase)
		sChecksum = sumSHA1.Get(reinterpret_cast<const PLCore::uint8*>("abcdefghijklMnopqrstuvwxyz"), static_cast<PLCore::uint32>(strlen("abcdefghijklMnopqrstuvwxyz")));
		CHECK(sChecksum  != "32d10c7b8cf96570ca04ce37f2a19d84240d3a89");

		// Alphabet and numbers
		sChecksum = sumSHA1.Get(reinterpret_cast<const PLCore::uint8*>("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"), static_cast<PLCore::uint32>(strlen("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")));
		CHECK_EQUAL("761c457bf73b14d27e9e9265c46f4b4dda11f940", sChecksum.GetASCII());

		// Corrupted alphabet and numbers ('9' removed)
		sChecksum = sumSHA1.Get(reinterpret_cast<const PLCore::uint8*>("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz012345678"), static_cast<PLCore::uint32>(strlen("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz012345678")));
		CHECK(sChecksum  != "761c457bf73b14d27e9e9265c46f4b4dda11f940");
	}

	// ChecksumSHA1: Get(const String &sString)
	TEST_FIXTURE(ConstructTest, ChecksumSHA1__Get_const_String__sString_) {
		// Alphabet
		sChecksum = sumSHA1.Get("abcdefghijklmnopqrstuvwxyz");
		CHECK_EQUAL("32d10c7b8cf96570ca04ce37f2a19d84240d3a89", sChecksum.GetASCII());

		// Corrupted alphabet (one of the letters in the alphabet (in this case 'm') is changed to uppercase)
		sChecksum = sumSHA1.Get("abcdefghijklMnopqrstuvwxyz");
		CHECK(sChecksum  != "32d10c7b8cf96570ca04ce37f2a19d84240d3a89");

		// Alphabet and numbers
		sChecksum = sumSHA1.Get("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
		CHECK_EQUAL("761c457bf73b14d27e9e9265c46f4b4dda11f940", sChecksum.GetASCII());

		// Corrupted alphabet and numbers ('9' removed)
		sChecksum = sumSHA1.Get("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz012345678");
		CHECK(sChecksum  != "761c457bf73b14d27e9e9265c46f4b4dda11f940");

		// Unicode
		sChecksum = sumSHA1.Get(L"\u65e5\u672c\u8a9e");
		CHECK_EQUAL("5c9941a48c296ef5cc2f267874c8dafeeb36a385", sChecksum.GetASCII());

		// Alphabet and numbers - this time as Unicode
		sChecksum = sumSHA1.Get(L"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
		CHECK(sChecksum  != "5c9941a48c296ef5cc2f267874c8dafeeb36a385");
	}

	// ChecksumSHA1: Get(File &cFile)
	TEST_FIXTURE(ConstructTest, ChecksumSHA1__Get_File__cFile_) {
		// Check 'demotest.xml'
		sChecksum = CheckFile(sumSHA1, "demotest.xml");
		CHECK_EQUAL("f3f9259f1a56e9dc2e47a89342c3cfa7c5a72a98", sChecksum.GetASCII());

		// Check 'tokenizer.txt'
		sChecksum = CheckFile(sumSHA1, "tokenizer.txt");
		CHECK_EQUAL("1426466cd8518ae4a630a54acc082de634fd44ed", sChecksum.GetASCII());

		// Check 'test.zip'
		sChecksum = CheckFile(sumSHA1, "test.zip");
		CHECK_EQUAL("ddc29c7c422d8ef3c0a2102b61a56f0f899367d3", sChecksum.GetASCII());
	}

	// ChecksumSHA1: GetFile(const String &sFilename)
	TEST_FIXTURE(ConstructTest, ChecksumSHA1__Get_const_String__sFilename_) {
		// Check 'demotest.xml'
		sChecksum = sumSHA1.GetFile("demotest.xml");
		CHECK_EQUAL("f3f9259f1a56e9dc2e47a89342c3cfa7c5a72a98", sChecksum.GetASCII());

		// Check 'tokenizer.txt'
		sChecksum = sumSHA1.GetFile("tokenizer.txt");
		CHECK_EQUAL("1426466cd8518ae4a630a54acc082de634fd44ed", sChecksum.GetASCII());

		// Check 'test.zip'
		sChecksum = sumSHA1.GetFile("test.zip");
		CHECK_EQUAL("ddc29c7c422d8ef3c0a2102b61a56f0f899367d3", sChecksum.GetASCII());
	}
}